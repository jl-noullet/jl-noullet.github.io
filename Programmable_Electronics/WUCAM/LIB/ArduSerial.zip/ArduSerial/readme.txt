Serial port communication in Java (possibly via an USB - CDC class device)

Library used :
  JSSC (Java Simple Serial Connector), supported on Windows, Mac-OS, Linux
  https://github.com/java-native/jssc
  jssc-2.9.6.jar

Demo GUI : FXcom.java: enables the user to send (with or without end-of-line characters) and receive text.
This program requests from the O.S. the list of serial ports (real RS232 or virtual over USB)
- if there is no serial port available, the program aborts
- if there is exactly on port available, the program opens this one
- if there is more than one, the program aborts. In this case, the user will have to
  specifiy the port to use in the command line
Some operating systems, like Windows 10, create temporary COM ports only while a USB device is physically connected.

For testing this library, an Arduino board may be used as a device, the ArduSerial program is available 
for this purpose.
 

Communication sur port serie en Java (possiblement via USB - CDC class device)

Bibliotheque utilisee :
  JSSC (Java Simple Serial Connector), supporte Windows, Mac-OS, Linux
  https://github.com/java-native/jssc
  jssc-2.9.6.jar

GUI de demonstration : FXcom.java: permet a l'utilisateur d'envoyer (avec ou sans fin de ligne) et recevoir du texte.
Ce programme demande au système d'exploitation la liste des ports série (RS232 réels et virtuels via USB)
- s'il n'y a aucun port disponible, le programme abandonne
- s'il y a exactement un port disponible, le programme ouvre celui-ci
- s'il y a plus d'un port disponible, le programme abandonne. Dans ce cas l'utilisateur devra indiquer le port désiré comme argument dans la ligne de commande.
Certains systemes d'exploitation (notamment Windows 10) créent un port COM temporaire seulement tant qu'un device est connecté physiquement.

Pour tester ce programme, on peut utiliser une carte Arduino comme device, le programme ArduSerial.ino est proposé pour cela.
