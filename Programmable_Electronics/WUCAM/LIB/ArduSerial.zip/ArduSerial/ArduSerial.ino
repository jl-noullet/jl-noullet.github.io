// this program sends back the echo of every character it receives on the serial line, 
// including newlines,  
// it makes lower case lettes uppercase and conversely

 void setup() {
Serial.begin( 9600 );
Serial.print( "RESET\n" );
}

void loop() {
if  ( Serial.available() )
    {
    char c = Serial.read();
    // change case of letters, leave other codes unchanged
    if  (
           ( ( c >= 'A' ) && ( c <= 'Z' ) ) ||
           ( ( c >= 'a' ) && ( c <= 'z' ) )
        )
        c ^= 0x20;
    Serial.print( c );
    }
}
