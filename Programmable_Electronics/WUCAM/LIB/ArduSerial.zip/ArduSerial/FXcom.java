/*
N:\Appli\jdk-22\bin\javac -classpath ".;jssc-2.9.6.jar" --module-path N:\Appli\javafx-21\lib --add-modules javafx.controls FXcom.java
N:\Appli\jdk-22\bin\java  -classpath ".;jssc-2.9.6.jar" --module-path N:\Appli\javafx-21\lib --add-modules javafx.controls FXcom
*/

/* ce programme propose un terminal de dialogue avec un port serie (port COM sous Windows)

Note: it is normal to obtain in stderr a warning such as :
	SLF4J: Failed to load class "org.slf4j.impl.StaticLoggerBinder".
	SLF4J: Defaulting to no-operation (NOP) logger implementation
It is about an optional logger system which is not needed in general.
*/

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.application.Platform;
import jssc.*;

public class FXcom extends Application {

// Widgets
private TextArea larea;
private TextField entry1;
private Button but1;	// send
private Button but2;	// send with new line

// objects
static SerialPort port;
static String portName;
static ComThread comListener;	// the serial port thread

// methods
public void modalPop( String texto ) {
	Alert alert = new Alert(Alert.AlertType.WARNING);
	alert.setTitle("Problem...");
	alert.setHeaderText(null);
	alert.setContentText(texto);
	alert.showAndWait();
	}

public void showText( String texto ) {
	System.out.println( texto );
	// the actions requested by the COM thread must be placed in a queue managed by JavaFX loop.
	Platform.runLater( new Runnable() {
		@Override
		public void run() {
			larea.appendText("\n" + texto);
			}
		} );
	}


public String guessPort() {
	String[] portlist = jssc.SerialPortList.getPortNames();
	if	( portlist.length == 0 )
		{ System.out.println("No serial port available"); return null; }
	else if ( portlist.length > 1 )
		{
		String msg = "Too many serial ports :\n";
		for	( String port : portlist )
			msg += ( port + ", ");
		msg += "\nChoose one and restart the program with its name as command argument";
		System.out.println( msg );
		modalPop( msg );
		return null;
		}
	else	return portlist[0];
	}

public class ComThread extends Thread {
	// la methode run() est appellee par la methode start() de la superclass Thread
	public void run() {
		try	{
			byte message[] = new byte[128];
			int i = 0; byte c;
			while	( true )
				{
				if	( Thread.currentThread().isInterrupted() )
					{
					System.out.println("Stopping ComThread");
					return;
					// Note : a Java thread cannot be killed by the interrupt method
					// while it is waiting for a system call to complete. 
					// in this case it will be terminated only when the next byte is received
					}
				c = port.readBytes(1)[0];	// read 1 byte (blocking)
				// buffer a line of text
				if	( ( c == 10 ) || ( i >= message.length ) )
					{
					String s = new String( message, 0, i );
					showText( s );
					i = 0;
					}
				else 	message[i++] = c;
				}
			} catch( Exception ex ) { System.out.println("Arrrgh..."); }
		} // run()
	} // nested class



public void sendText( String texto ) {
	if	( port != null )
		try	{
			port.writeBytes(texto.getBytes());
			} catch	( SerialPortException ex ) {
				System.out.println("cannot write to " + portName );
				modalPop("cannot write to " + portName );
				System.exit(2);
				}
	}

@Override
public void start(Stage lestage) throws Exception {
        // Create the JavaFX scene graph root container
        VBox rootBox = new VBox( 10 );
	rootBox.setPadding( new Insets( 12 ) );

        /* Create and set up a scrollable text area with initial text */
        larea = new TextArea("");
        larea.setPrefSize(600, 300);
        larea.setWrapText(true);
        larea.setEditable(false);
        ScrollPane lescroll = new ScrollPane( larea );
        rootBox.getChildren().add(lescroll);
	

	// text entry with two "Send" buttons
        HBox sendBox = new HBox( 10 );

	but1 = new Button("Send");
	but1.setOnAction( action ->
		{
		sendText( entry1.getText() ); entry1.setText("");
		} );
        sendBox.getChildren().add(but1);

	entry1 = new TextField();
	entry1.setPrefWidth( 450 );
	entry1.setText( "" );
        sendBox.getChildren().add(entry1);

	but2 = new Button("Send NL");
	but2.setOnAction( action ->
		{
		sendText( entry1.getText() + "\n" ); entry1.setText("");
		} );
        sendBox.getChildren().add(but2);

	rootBox.getChildren().add(sendBox);

        // Create and show the scene
        Scene lascene = new Scene(rootBox);
        lestage.setScene(lascene);
        lestage.setTitle("FWcom Serial terminal");
        lestage.show();
        
	if	( portName == null )
		portName = guessPort();
	if	( portName == null )
		System.exit(1);

	// demarrer la com
	System.out.println("Port to open : " + portName );
	port = new SerialPort( portName );
	try	{
		port.openPort();
		} catch	( SerialPortException ex ) {
			System.out.println("Cannot open port " + portName );
			modalPop("Cannot open port " + portName );
			System.exit(3);
			}
	port.setParams( 9600, 8, 1, 0 );	// bauds, bits, stops, parity
	comListener = new ComThread();
	comListener.start();
	System.out.println("comListener started");
	} // start method

	@Override
	public void stop() {
        // The stop() method is automatically called when the JavaFX main loop is exited
	if	( comListener != null )	// kill the serial thread
		comListener.interrupt();
	}

	public static void main(String[] args) {
	if	( args.length >= 1 )
		portName = args[0];
	else	portName = null;
        launch(args);
	}
}
