#include <SPI.h>
#include "cc1101_cal.h"

/* SPI, full duplex
 * SCK  = 13
 * MISO = 12
 * MOSI = 11
 * SS = 10
 */
void SPI1_init(void)
{
SPI.begin();
SPI.beginTransaction( SPISettings( 2000000, MSBFIRST, SPI_MODE0 ) );
pinMode( 10, OUTPUT );
pinMode( 2, INPUT_PULLUP );  // GDO0
digitalWrite( 10, 1 );  // SS hi
}

// write and read cnt bytes in one transaction
void SPI1_multi_byte( unsigned char * txbuf, unsigned char * rxbuf, byte cnt )
{
digitalWrite( 10, 0 );  // SS low
while ( digitalRead( 12 ) ) // wait for wake-up <==> MISO low
  {}
for ( byte i = 0; i < cnt; i++ )
    *(rxbuf++) = SPI.transfer( *(txbuf++) );
digitalWrite( 10, 1 );  // SS hi
}

///
/// singleton
///
CC1101 CC;

///
/// CC1101 methods
///

// burst read, returns the addresse of a byte buffer
// this buffer may be modified by a subsequent read_reg() NOT THREAD SAFE
unsigned char * CC1101::read_regs( byte start_adr, byte cnt ) {
  txbuf[0] = 0xC0 | ( start_adr & 0x3f );
  SPI1_multi_byte( txbuf, rxbuf, cnt+1 );
  return rxbuf+1;
  }
// burst write, takes the addresse of a byte array
// this buffer may be modified by a subsequent read_reg() NOT THREAD SAFE
void CC1101::write_regs( byte start_adr, const unsigned char * src, byte cnt ) {
  txbuf[0] = 0x40 | ( start_adr & 0x3f );
  memcpy( txbuf+1, src, cnt );
  SPI1_multi_byte( txbuf, rxbuf, cnt+1 );
  }


///
/// experiments
///

// read all 47 registers from 00 to 2E
void CC1101::dump_config()
{
unsigned char * fbuf = read_regs( 0, 0x2F );
for ( byte i = 0; i < 0x2F; i++ )
    {
    snprintf( tbuf, sizeof(tbuf), "reg %02x : %02x\n", i, fbuf[i] );
    Serial.print( tbuf );
    }
snprintf( tbuf, sizeof(tbuf), "F = %lu kHz\n", synth_frequ_to_kHz(get_synth_frequ()) );
Serial.print( tbuf );
}

// dump PATABLE
void CC1101::dump_patable()
{
snprintf( tbuf, sizeof(tbuf), "PATABLE : %d -> ", get_power() );
Serial.print( tbuf );
unsigned char * fbuf = get_patable();
for	( byte i = 0; i < 8; i++ )
	{
	snprintf( tbuf, sizeof(tbuf), " %02x", fbuf[i] );
	Serial.print( tbuf );
	}
Serial.print("\n");
}

byte CC1101::cw_radio_init()
{
SPI1_init();
delay(1000);
if  ( ( read_reg( CC1101_SYNC1 ) != 0xD3 ) || ( read_reg( CC1101_SYNC0 ) != 0x91 ) )
    return 3;
preset_P10AA();
write_strobe( CC1101_SIDLE );
return 0;
}
